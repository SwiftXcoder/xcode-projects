//
//  CarEconomyClass.swift
//  MotorVehicles


import Foundation

class CarEconomy {
    
    var co2: Int
    var fuelType: String
    
    init() {
        co2 = 100
        fuelType = "unknown"
    }
    
    class func maximumCO2allowed() -> Int {
        return 145
        }
}


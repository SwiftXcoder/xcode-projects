
/*
Chapter 7 : Swift Classes, Objects and Methods
Swift 2 for absolute beginners.

Different project to the one in the book (which is a radio thing)
This defines two classes, one called MotorVehicleClass and one called CarEconomyClass
5 buttons are created with the interface builder and linked to the various outlet labels
when a button is clicked, a class is instantiated and the information displayed in the labels
the CarEconomy class is called as a class method, just to demo this and return
the value predetermined inside.
*/

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Page 129 exercise "how could you fix it so user doesn't see the label text
        // easy way is to set it first in the Interface tool
        // or you can add the initial values here...
        modelName.text = "unknown model"
        engineSize.text = "unspecified"
        transmission.text = "not known"
        colour.text = "unidentified"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Outlet definitions
    @IBOutlet weak var modelName: UILabel!
    @IBOutlet weak var engineSize: UILabel!
    @IBOutlet weak var transmission: UILabel!
    @IBOutlet weak var colour: UILabel!
    @IBOutlet weak var economyNotes: UILabel!
    @IBOutlet weak var vehicleDetails: UILabel!
    
    
    /* Button definitions
    are all basically the same, create a class of 'MotorVehicle' with initialisation parameters
    then place those values into the text for the outlet labels
    The only slight alteration is engineSize has to be a String to output properly
    As well as the properties, there is a method which returns the economy report based on engine size!
    
    Note that the first line, writing to vehicleDetails text label is pulled as a class method directly
    from the CarEconomy class, the rest are instantiated class properties and methods
    (see odd exercise and weird explanation Page 107 in book)
    */
    @IBAction func choosePeugeot(sender: UIButton) {
    
        let peugeot = MotorVehicle (modelName: "Peugeot 2008", engineSize: 1.6, transmission: "5 speed manual", colour: "Black")
        
        vehicleDetails.text = String("Maximum CO2 allowed is \(CarEconomy.maximumCO2allowed()) grams per kilometre")
        modelName.text = peugeot.modelName
        engineSize.text = String(peugeot.engineSize)
        transmission.text = peugeot.transmission
        colour.text = peugeot.colour
        economyNotes.text = peugeot.IsCarEconomical()
    }
    
    @IBAction func toyota(sender: UIButton) {
        
        let toyota = MotorVehicle (modelName: "Toyota GT86", engineSize: 2.8, transmission: "6 speed manual", colour: "Red")
        
        modelName.text = toyota.modelName
        engineSize.text = String(toyota.engineSize)
        transmission.text = toyota.transmission
        colour.text = toyota.colour
        economyNotes.text = toyota.IsCarEconomical()
    }
    
    @IBAction func ford(sender: UIButton) {
        
        let ford = MotorVehicle (modelName: "Ford Focus", engineSize: 1.9, transmission: "6 speed automatic", colour: "Blue")
        
        modelName.text = ford.modelName
        engineSize.text = String(ford.engineSize)
        transmission.text = ford.transmission
        colour.text = ford.colour
        economyNotes.text = ford.IsCarEconomical()
    }
    
    @IBAction func volkswagen(sender: UIButton) {
        
        let volkswagen = MotorVehicle (modelName: "Golf GTI", engineSize: 1.8, transmission: "4 Speed Manual", colour: "Silver")
        
        modelName.text = volkswagen.modelName
        engineSize.text = String(volkswagen.engineSize)
        transmission.text = volkswagen.transmission
        colour.text = volkswagen.colour
        economyNotes.text = volkswagen.IsCarEconomical()
    }
    
    @IBAction func audi(sender: UIButton) {
        
        let audi = MotorVehicle (modelName: "TT", engineSize: 2.5, transmission: "6 speed manual", colour: "Grey")
        
        modelName.text = audi.modelName
        engineSize.text = String(audi.engineSize)
        transmission.text = audi.transmission
        colour.text = audi.colour
        economyNotes.text = audi.IsCarEconomical()
    }

    
    
    
    
    
    
    
    
    
    
}


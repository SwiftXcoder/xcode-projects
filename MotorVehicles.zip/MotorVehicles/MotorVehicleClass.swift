//
//  MotorVehicleClass.swift
//  MotorVehicles


import Foundation

class MotorVehicle {
    var modelName : String
    var engineSize : Float
    var steeringWheel : Bool
    var brake : String
    var transmission : String
    var colour : String
    
    func IsCarEconomical() -> String {
        if engineSize > 1.9 {
            return ("This is a \(modelName) with a \(engineSize) engine. Not Economical.")
        } else {
        return ("This is a \(modelName) with a little \(engineSize) engine. This is economical.")
        }
    }
        
    // default initialiser if no parameters are sent when instantiating the class
    init () {
        modelName = "Unknown"
        engineSize = 0
        steeringWheel = true
        brake = "Powered"
        transmission = "Automatic"
        colour = "Unknown"
    }
    
    // initialisers with parameters
    init (modelName : String, engineSize : Float, transmission : String, colour : String) {
        self.modelName = modelName
        self.engineSize = engineSize
        self.transmission = transmission
        self.colour = colour
        // plus all the other stuff
        self.steeringWheel = true
        self.brake = "Powered"
    }
}
